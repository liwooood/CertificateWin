NPRuntime Plugin

This sample plugin can be scripted, JavaScript can call into the plugin via NPRuntime.
