//kk: common and often used headers

#define _WIN32_WINNT 0x501

#include <windows.h>
#include <windowsx.h>
#include <stdio.h>
#include <atlstr.h>

//Mozilla-API
#include <npfunctions.h>
#include <npruntime.h>
#include "npruntime.h"

#define TRACE __noop
